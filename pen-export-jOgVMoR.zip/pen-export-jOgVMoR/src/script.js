function calculateCalories() {
  var weight = document.getElementById("weight").value;
  var height = document.getElementById("height").value;
  var age = document.getElementById("age").value;
  var activity = document.getElementById("activity").value;

  if (weight && height && age) {
    var bmr;

    // معادلة BMR (Basal Metabolic Rate)
    bmr = 10 * weight + 6.25 * height - 5 * age + 5;

    var calories;
    if (activity === "low") {
      calories = bmr * 1.2;
    } else if (activity === "moderate") {
      calories = bmr * 1.55;
    } else if (activity === "high") {
      calories = bmr * 1.9;
    }

    document.getElementById("result").innerText =
      "السعرات الحرارية اليومية المطلوبة: " +
      Math.round(calories) +
      " سعر حراري.";
  } else {
    document.getElementById("result").innerText = "من فضلك أدخل كل البيانات.";
  }
}
